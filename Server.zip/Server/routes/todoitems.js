const router = require('express').Router();

const todoItemsModel = require('../models/todoitems');

// Insert item
router.post('/api/item', async (req, res)=>{
    try{
        const newItem = new todoItemsModel({
            item: req.body.item
        })
        // save
        const save = await newItem.save()
        res.status(200).json("Item added successfully.")
    } catch (error) {
        res.json(error)
        
    }
})


module.exports = router;