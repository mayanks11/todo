const mongoose = require('mongoose');

// create schema
const TodoItemSchema = new mongoose.Schema({
    item: {
        type: String
    }
})


mongoose.exports = mongoose.model('todo', TodoItemSchema);
