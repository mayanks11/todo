const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv').config();

const app = express();

app.use(express.json());

const PORT = process.env.PORT || 2000


mongoose.connect(process.env.DB_CONN)
.then(()=> console.log('Database connected'))
.catch(err => console.log(err))

// import routes

const TodoItemRoute = require('./routes/todoitems');

app.use('/', TodoItemRoute);



//PORT: 4000
app.listen(PORT, ()=> console.log("Server connected") );